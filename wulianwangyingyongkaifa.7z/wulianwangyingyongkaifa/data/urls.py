from django.conf.urls import url,include
from django.contrib import admin
from  data.views import home
urlpatterns = [
    # url(r'^admin/', admin.site.urls),
    url(r'^index/', home.index),
    url(r'^login/', home.login),
    url(r'^search/', home.search),
    url(r'^logout/', home.logout),
    url(r'^stuindex/', home.stuindex),
    url(r'^swindex/', home.swindex),
    url(r'^sjindex/', home.sjindex),

    url(r'^userlist/', home.userlist),
    url(r'^adduser/', home.adduser),
    url(r'^edituser/(\d+)/', home.edituser),
    url(r'^deluser/(\d+)/', home.deluser),

    url(r'^goodlist/', home.goodlist),
    url(r'^addgood/', home.addgood),
    url(r'^editgood/(\d+)/', home.editgood),
    url(r'^delgood/(\d+)/', home.delgood),

    url(r'^exportlist/', home.exportlist),
    url(r'^editlist/(\d+)/', home.editlist),

    url(r'^startlist/', home.startlist),
    url(r'^delstart/(\d+)/', home.delstart),

]