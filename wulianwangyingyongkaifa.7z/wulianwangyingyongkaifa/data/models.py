from django.db import models
#用户管理表
class UserManager(models.Model):
    username = models.CharField(verbose_name="用户名", max_length=32)
    password = models.CharField(verbose_name="密码", max_length=64)
    type_choice = (
        (1, '财务员'),
        (2, '仓库管理员'),
        (3, '审计员'),
        (4, '超级管理员'),
    )
    usertype = models.IntegerField(verbose_name='用户类型', choices=type_choice)
    def __str__(self):
        return self.username
#商品信息表
class Goodlist(models.Model):
    name = models.CharField(verbose_name="商品名称",max_length=128)
    num = models.CharField(verbose_name="商品编号",max_length=128)
    type = models.CharField(verbose_name="商品种类",max_length=128)
    address = models.CharField(verbose_name="商品产地",max_length=128)
    start_date = models.CharField(verbose_name="上架日期",max_length=128)
    number = models.IntegerField(verbose_name="总数量",max_length=128)
    def __str__(self):
        return self.name

#出入库管理表
class Exportlist(models.Model):
    name = models.CharField(verbose_name="商品名称", max_length=128)
    number = models.IntegerField(verbose_name="总数量", max_length=128)
    def __str__(self):
        return self.name

#出入库记录表
class Makelist(models.Model):
    name = models.CharField(verbose_name="商品名称", max_length=128)
    number = models.IntegerField(verbose_name="操作数量", max_length=128)
    status = models.CharField(verbose_name="出入库状态",max_length=128)
    operate = models.CharField(verbose_name="操作人",max_length=128)
    def __str__(self):
        return self.name