from data  import  models
from django.forms import ModelForm
from django import  forms
#校验输入的设备信息字段不能为空
class GoodModelForm(ModelForm):
    class Meta:
        model = models.Goodlist
        fields = ['name','num','type','address','start_date']
        widgets = {
            'name':forms.TextInput(attrs={'class':'form-control','placeholder':'商品名称'}),
            'num':forms.TextInput(attrs={'class':'form-control','placeholder':'商品编号'}),
            'type':forms.TextInput(attrs={'class':'form-control','placeholder':'商品种类'}),
            'address':forms.TextInput(attrs={'class':'form-control','placeholder':'商品产地'}),
            'start_date':forms.TextInput(attrs={'class':'form-control','placeholder':'上架日期','id':'tt'}),
            # 'number':forms.TextInput(attrs={'class':'form-control','placeholder':'总数量'}),
        }
        error_messages = {
            'name':{
                'required':'不能为空'
            },
            'num': {
                'required': '不能为空'
            },
            'type': {
                'required': '不能为空'
            },
            'address': {
                'required': '不能为空'
            },
            'start_date': {
                'required': '不能为空'
            },

        }