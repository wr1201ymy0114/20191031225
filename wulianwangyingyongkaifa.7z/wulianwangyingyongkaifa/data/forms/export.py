from data  import  models
from django.forms import ModelForm
from django import  forms
#校验输入的设备信息字段不能为空
class ExportModelForm(ModelForm):
    class Meta:
        model = models.Exportlist
        fields = ['name','number']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '商品名称'}),
            'number':forms.TextInput(attrs={'class':'form-control','placeholder':'出入库数量'}),
        }
        error_messages = {
            'name': {
                'required': '不能为空'
            },
            'number':{
                'required':'不能为空'
            }
        }