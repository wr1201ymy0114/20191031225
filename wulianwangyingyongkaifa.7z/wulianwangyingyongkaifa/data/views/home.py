from django.shortcuts import HttpResponse,render,redirect
from data import models
from data.forms.user import UserModelForm
from data.forms.good import GoodModelForm
from data.forms.allgood import GoodAModelForm
from data.forms.export import ExportModelForm
from data.views import my_page
from functools import wraps
CW = []

#判断是否登录的装饰器
def check_login(func):
    @wraps(func)  #装饰器修复技术
    def inner(request,*args,**kwargs):
        #已经登录过的继续执行
        ret = request.get_signed_cookie("is_login", default="0", salt="dsb")
        if ret == "1":
            return func(request,*args,**kwargs)
        #没有登录过的跳转登录界面
        else:
            #获取当前访问的URl
            next_url = request.path_info
            print(next_url)
            return redirect("/data/login/?next={}".format(next_url))
    return inner
def login(request):
    errmsg = ""
    if request.method == "POST":
        usertype = request.POST['seltype']
        username = request.POST['username']
        password = request.POST['password']
        next_url = request.GET.get("next")
        obj = models.UserManager.objects.filter(username=username,password=password)
        if models.UserManager.objects.filter(username=username,password=password,usertype=1):
            if next_url:
                rep = redirect(next_url)
            else:
                rep = redirect('/data/stuindex/')
            rep.set_signed_cookie("is_login", "1", salt="dsb", max_age=60 * 60 * 24 * 7)
            return rep
        elif models.UserManager.objects.filter(username=username,password=password,usertype=2):
                CW.append(username)
                if next_url:
                    rep = redirect(next_url)
                else:
                    rep = redirect('/data/swindex/')
                rep.set_signed_cookie("is_login", "1", salt="dsb", max_age=60 * 60 * 24 * 7)
                return rep

        elif models.UserManager.objects.filter(username=username,password=password,usertype=3):
            if next_url:
                rep = redirect(next_url)
            else:
                rep = redirect('/data/sjindex/')
            rep.set_signed_cookie("is_login", "1", salt="dsb", max_age=60 * 60 * 24 * 7)
            return rep
        elif models.UserManager.objects.filter(username=username,password=password,usertype=4):
            if next_url:
                rep = redirect(next_url)
            else:
                rep = redirect('/data/index/')
            rep.set_signed_cookie("is_login", "1", salt="dsb", max_age=60 * 60 * 24 * 7)
            return rep
        else:
            return render(request, 'login.html', {"errmsg": "用户名或密码输入错误"})
    return render(request, 'login.html')

#退出函数
def logout(request):
    rep = redirect("/data/login/")
    rep.delete_cookie("is_login")
    return rep

@check_login
def index(request):
    return render(request,'index.html')

@check_login
def stuindex(request):
    return render(request,'stuindex.html')

@check_login
def swindex(request):
    return render(request,'swindex.html')

@check_login
def sjindex(request):
    return render(request,'sjindex.html')
@check_login
def userlist(request):
    teach_queryset = models.UserManager.objects.all()
    return render(request, 'userlist.html', {"teach_queryset": teach_queryset})

@check_login
def adduser(request):
    if request.method == "GET":
        form = UserModelForm()
        return render(request, 'user_form.html', {"form": form})
    form = UserModelForm(data=request.POST)
    if form.is_valid():
        form.save()
        return redirect('/data/userlist/')
    return render(request, 'user_form.html', {"form": form})

@check_login
def edituser(request, nid):
    obj = models.UserManager.objects.filter(id=nid).first()
    if request.method == "GET":
        form = UserModelForm(instance=obj)
        return render(request, 'user_form.html', {"form": form})
    form = UserModelForm(data=request.POST, instance=obj)
    if form.is_valid():
        form.save()
        return redirect('/data/userlist/')
    return render(request, 'user_form.html', {"form": form})

@check_login
def deluser(request, nid):
    models.UserManager.objects.filter(id=nid).delete()
    return redirect('/data/userlist/')

@check_login
def goodlist(request):
    try:
        page_num = request.GET.get("page")
    except Exception as e:
        page_num = 1
    total_count = models.Goodlist.objects.all().count()
    page = my_page.Page(page_num, total_count, per_pag=8, url_prefix="/data/goodlist/", max_page=11)
    page_html = page.page_html()
    teach_queryset = models.Goodlist.objects.all()[page.data_start:page.data_end]
    return render(request, 'goodlist.html', {"teach_queryset": teach_queryset,'page_html':page_html})

@check_login
def addgood(request):
    if request.method == "GET":
        form = GoodAModelForm()
        return render(request, 'good_form.html', {"form": form})
    form = GoodAModelForm(data=request.POST)
    if form.is_valid():
        name = form['name'].value()
        number  = form['number'].value()
        obj = models.Exportlist.objects.create(name=name,number=number)
        form.save()
        return redirect('/data/goodlist/')
    return render(request, 'good_form.html', {"form": form})

@check_login
def editgood(request, nid):
    obj = models.Goodlist.objects.filter(id=nid).first()
    if request.method == "GET":
        form = GoodModelForm(instance=obj)
        return render(request, 'good_form.html', {"form": form})
    form = GoodModelForm(data=request.POST, instance=obj)
    if form.is_valid():
        form.save()
        return redirect('/data/goodlist/')
    return render(request, 'good_form.html', {"form": form})

@check_login
def delgood(request, nid):
    models.Goodlist.objects.filter(id=nid).delete()
    return redirect('/data/goodlist/')

@check_login
def exportlist(request):
    teach_queryset = models.Exportlist.objects.all()
    return render(request, 'exportlist.html', {"teach_queryset": teach_queryset})

@check_login
def editlist(request, nid):
    obj = models.Exportlist.objects.filter(id=nid).first()
    if request.method == "GET":
        form = ExportModelForm(instance=obj)
        return render(request, 'export_form.html', {"form": form})
    form = ExportModelForm(data=request.POST, instance=obj)
    if form.is_valid():
        name = form['name'].value()
        obj = models.Goodlist.objects.filter(name=name).all()
        for i in obj:
            start_number = i.number
            end_number = form['number'].value()
            last_number = int(start_number) - int(end_number)

            if '-' in str(last_number):
                status = '入库'
                number = abs(last_number)
                operate = CW[0]
                obj = models.Makelist.objects.create(name=name,status=status,number=number,operate=operate)
                obj.save()
                good = models.Goodlist.objects.filter(name=name).all().update(number=end_number)
                # for i in good:
                #     good = models.Goodlist.objects.create(name=i.name,num=i.num,type=i.type,address=i.address,start_date=i.start_date,number=end_number)
                #     good.save()

            else:
                status = '出库'
                number = last_number
                operate = CW[0]
                obj = models.Makelist.objects.create(name=name, status=status, number=number, operate=operate)
                obj.save()
                good = models.Goodlist.objects.filter(name=name).all().update(number=end_number)
                # for i in good:
                #     good = models.Goodlist.objects.create(name=i.name,num=i.num,type=i.type,address=i.address,start_date=i.start_date,number=end_number)
                #     good.save()
        form.save()
        return redirect('/data/exportlist/')
    return render(request, 'export_form.html', {"form": form})


@check_login
def startlist(request):
    teach_queryset = models.Makelist.objects.all()
    return render(request, 'startlist.html', {"teach_queryset": teach_queryset})

@check_login
def delstart(request, nid):
    models.Makelist.objects.filter(id=nid).delete()
    return redirect('/data/startlist/')

def search(request):
    if request.method == "POST":
        tmp = request.POST["ipholder"]
        teach_queryset = models.Makelist.objects.filter(status=tmp).all()
        return render(request, 'startlist.html', {"teach_queryset": teach_queryset})