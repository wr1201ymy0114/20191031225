import email
from django.db import models
from datetime import datetime

class User(models.Model):
    username = models.CharField(max_length=50)    #员工账号
    nickname = models.CharField(max_length=50)    #昵称
    telephone= models.CharField(max_length=255)
    password_hash = models.CharField(max_length=100)#密码
    password_salt = models.CharField(max_length=50)    #密码干扰值

    def toDict(self):
        return {'id':self.id,'username':self.username,'nickname':self.nickname,'telephone':self.telephone,'password_hash':self.password_hash,'password_salt':self.password_salt}

    class Meta:
        db_table = "user"  # 更改表名


class Tenant(models.Model):
    username = models.CharField(max_length=50)    #员工账号
    nickname = models.CharField(max_length=50)    #昵称
    telephone= models.CharField(max_length=255)
    password_hash = models.CharField(max_length=100)#密码
    password_salt = models.CharField(max_length=50) #密码干扰值

    def toDict(self):
        return {'id':self.id,'username':self.username,'nickname':self.nickname,'telephone':self.telephone,'password_hash':self.password_hash,'password_salt':self.password_salt}

    class Meta:
        db_table = "tenant"  # 更改表名

class Submit(models.Model):
    username = models.CharField(max_length=50)    #账号
    idcard= models.CharField(max_length=5)
    adress=  models.CharField(max_length=20)
    message = models.CharField(max_length=255)
    status = models.IntegerField(default=1)
   
    
    def toDict(self):
        return {'id':self.id,'username':self.username,'idcard':self.idcard,'adress':self.adress,'message':self.message,'status':self.status}

    class Meta:
        db_table = "submit"  # 更改表名