from django.urls import path
from app.views import index

urlpatterns = [
    #登录
    path('web/base', index.base,name='web_base'),
    path('add', index.add,name='add'),
    path('web/add1', index.add1,name='add1'),

    path('login', index.login,name='login'),
    path('dologin', index.dologin,name='dologin'),

    path('signup', index.signup,name='signup'),
    path('verify', index.verify,name='web_verify'),

    path('web/shouye', index.shouye,name='web_shouye'),
    path('web/shishi', index.shishi,name='web_shishi'),

    path('web/shebei', index.shebei,name='web_shebei'),
    path('web/yujing', index.yujing,name='web_yujing'),

    
    path('web/signup1', index.signup1,name='signup1'),

    path('web/logout', index.logout,name='web_logout'),
   
]
